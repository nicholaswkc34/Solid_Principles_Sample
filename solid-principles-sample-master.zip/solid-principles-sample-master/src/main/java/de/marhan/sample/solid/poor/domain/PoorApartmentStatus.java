package de.marhan.sample.solid.poor.domain;

public enum PoorApartmentStatus {
	free, reserved, rented
}
