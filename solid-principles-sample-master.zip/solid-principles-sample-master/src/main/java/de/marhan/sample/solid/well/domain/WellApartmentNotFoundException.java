package de.marhan.sample.solid.well.domain;

public class WellApartmentNotFoundException extends RuntimeException {


	public WellApartmentNotFoundException(String message) {
		super(message);
	}
}
