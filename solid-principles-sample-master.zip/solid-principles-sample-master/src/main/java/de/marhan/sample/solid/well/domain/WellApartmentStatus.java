package de.marhan.sample.solid.well.domain;

public enum WellApartmentStatus {
	free, reserved, rented
}
