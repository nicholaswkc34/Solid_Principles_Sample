# Sample for SOLID Principles

WORK IN PROGRESS!


# Service hyperlinks

* [Swagger UI](http://localhost:9091/swagger-ui.html)
* [Actuator](http://localhost:9091/actuator)
* [H2 Console](http://localhost:9091/h2-console)

# H2 Console

    JDBC URL: jdbc:h2:mem:testdb
    User Name: sa
    Password: <leave blank>
    
# Legend for principles

* SRP - Single Responsibility Principle
* DIP - Dependency Inversion Principle